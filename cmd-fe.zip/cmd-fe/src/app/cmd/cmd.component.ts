import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmd',
  templateUrl: './cmd.component.html',
  styleUrls: ['./cmd.component.scss']
})
export class CmdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
