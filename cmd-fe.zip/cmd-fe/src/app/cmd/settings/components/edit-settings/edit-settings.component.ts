import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-settings',
  templateUrl: './edit-settings.component.html',
  styleUrls: ['./edit-settings.component.scss']
})
export class EditSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
