export interface settings_data {
name: string;
email:string,
phone_no:number,
speciality:string,
npi_no:number,
practice_loc:string
}