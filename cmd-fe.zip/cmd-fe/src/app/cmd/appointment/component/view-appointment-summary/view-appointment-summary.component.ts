import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-appointment-summary',
  templateUrl: './view-appointment-summary.component.html',
  styleUrls: ['./view-appointment-summary.component.scss']
})
export class ViewAppointmentSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
