import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-appointment-recommendations',
  templateUrl: './view-appointment-recommendations.component.html',
  styleUrls: ['./view-appointment-recommendations.component.scss']
})
export class ViewAppointmentRecommendationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
