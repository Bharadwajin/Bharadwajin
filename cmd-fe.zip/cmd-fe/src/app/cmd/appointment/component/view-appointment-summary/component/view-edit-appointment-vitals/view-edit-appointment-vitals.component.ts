import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-edit-appointment-vitals',
  templateUrl: './view-edit-appointment-vitals.component.html',
  styleUrls: ['./view-edit-appointment-vitals.component.scss']
})
export class ViewEditAppointmentVitalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
