import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-edit-appointment-comments',
  templateUrl: './view-edit-appointment-comments.component.html',
  styleUrls: ['./view-edit-appointment-comments.component.scss']
})
export class ViewEditAppointmentCommentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
