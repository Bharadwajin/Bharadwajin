import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-all-prescriptions',
  templateUrl: './view-all-prescriptions.component.html',
  styleUrls: ['./view-all-prescriptions.component.scss']
})
export class ViewAllPrescriptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
