import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-appointment-test',
  templateUrl: './view-appointment-test.component.html',
  styleUrls: ['./view-appointment-test.component.scss']
})
export class ViewAppointmentTestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
