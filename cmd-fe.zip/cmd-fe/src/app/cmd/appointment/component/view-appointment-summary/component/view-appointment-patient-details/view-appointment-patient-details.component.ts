import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-appointment-patient-details',
  templateUrl: './view-appointment-patient-details.component.html',
  styleUrls: ['./view-appointment-patient-details.component.scss']
})
export class ViewAppointmentPatientDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
