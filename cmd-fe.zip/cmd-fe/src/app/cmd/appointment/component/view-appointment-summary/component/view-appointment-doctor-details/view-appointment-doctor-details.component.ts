import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-appointment-doctor-details',
  templateUrl: './view-appointment-doctor-details.component.html',
  styleUrls: ['./view-appointment-doctor-details.component.scss']
})
export class ViewAppointmentDoctorDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
