import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-prescriptions',
  templateUrl: './add-edit-prescriptions.component.html',
  styleUrls: ['./add-edit-prescriptions.component.scss']
})
export class AddEditPrescriptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
