import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-appointment-comfirmation',
  templateUrl: './view-appointment-comfirmation.component.html',
  styleUrls: ['./view-appointment-comfirmation.component.scss']
})
export class ViewAppointmentComfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
